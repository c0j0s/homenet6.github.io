m_simpleTV.Defines={}
m_simpleTV.Defines.ID_PROXY_USE = 450
m_simpleTV.Defines.ID_PROXY_IP  = 451
m_simpleTV.Defines.ID_PROXY_PORT = 452

-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_KARTINA_LOGIN =1900
m_simpleTV.Defines.ID_EXT_KARTINA_PASS  =1901
m_simpleTV.Defines.ID_EXT_KARTINA_PASS2 =1902
m_simpleTV.Defines.ID_EXT_KARTINA_STREAM=1903
m_simpleTV.Defines.ID_EXT_KARTINA_BITRATE=1904
m_simpleTV.Defines.ID_EXT_KARTINA_USE_EPG=1905
m_simpleTV.Defines.ID_EXT_KARTINA_TIMESHIFT=1906
m_simpleTV.Defines.ID_EXT_KARTINA_USE=1907

-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_SOPCAST_USE =2400
m_simpleTV.Defines.ID_EXT_SOPCAST_PATH  =2401
-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_SOVOK_USE=2500
m_simpleTV.Defines.ID_EXT_SOVOK_LOGIN=2501
m_simpleTV.Defines.ID_EXT_SOVOK_PASS=2502
m_simpleTV.Defines.ID_EXT_SOVOK_PROXY=2503
m_simpleTV.Defines.ID_EXT_SOVOK_PROTECT_CODE=2504

-------------------------------------------------------------
m_simpleTV.Defines.ID_TORRENTSTREAM_ADDRESS=2800
m_simpleTV.Defines.ID_TORRENTSTREAM_PORT=2801
m_simpleTV.Defines.ID_TORRENTSTREAM_PATH=2802
m_simpleTV.Defines.ID_TORRENTSTREAM_AUTOSTART=2803
m_simpleTV.Defines.ID_TORRENTSTREAM_ALLOW_CHANGE_NAME=2804
m_simpleTV.Defines.ID_TORRENTSTREAM_PLAYERID=2805
m_simpleTV.Defines.ID_TORRENTSTREAM_ALLOW_SHOW_NAME=2806
m_simpleTV.Defines.ID_TORRENTSTREAM_ALLOW_AD  = 2807

-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_INETCOM_STATE = 500000
m_simpleTV.Defines.ID_EXT_INETCOM_LOGIN = 500001
m_simpleTV.Defines.ID_EXT_INETCOM_PASS  = 500002
-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_PSKOVLINE_ID_LSESS = 500100
m_simpleTV.Defines.ID_EXT_PSKOVLINE_LOGIN = 500101
m_simpleTV.Defines.ID_EXT_PSKOVLINE_PASS  = 500102
m_simpleTV.Defines.ID_EXT_PSKOVLINE_REMEMBER  = 500103

m_simpleTV.Defines.ID_EXT_TORRENTTV_LOGIN = 500200
m_simpleTV.Defines.ID_EXT_TORRENTTV_PASS  = 500201
m_simpleTV.Defines.ID_EXT_TORRENTTV_UPDATEPLSONSTART    = 500202
m_simpleTV.Defines.ID_EXT_TORRENTTV_UPDATEPLSONREFRESH  = 500203
m_simpleTV.Defines.ID_EXT_TORRENTTV_WITHOUTGROUP  = 500204
m_simpleTV.Defines.ID_EXT_TORRENTTV_HDGROUP  = 500205


m_simpleTV.Defines.ID_EXT_RAKETATV_UPDATEPLSONSTART    = 500300
m_simpleTV.Defines.ID_EXT_RAKETATV_UPDATEPLSONREFRESH  = 500301
m_simpleTV.Defines.ID_EXT_RAKETATV_WITHOUTGROUP  = 500302
m_simpleTV.Defines.ID_EXT_RAKETATV_HDGROUP  = 500303
-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_MEDIASEARCH_STRING = 500400
m_simpleTV.Defines.ID_EXT_MEDIASEARCH_LOGIN = 500401
m_simpleTV.Defines.ID_EXT_MEDIASEARCH_PASS = 500402
-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_1_TORRENTTV_MAIN_CONFIG = 500500
-------------------------------------------------------------
m_simpleTV.Defines.ID_EXT_VOD_BY_DMITRYR_START_MAIN_CONFIG = 500600
m_simpleTV.Defines.ID_EXT_VOD_BY_DMITRYR_END_MAIN_CONFIG = 500699

